# DB-First Headless CMS

Projektstruktur inklusive Admin-UI, Medienverwaltung, Audit-Logs und Themes.
